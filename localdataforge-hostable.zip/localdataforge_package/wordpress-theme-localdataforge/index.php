<?php get_header(); ?>
<main>
  <section class="hero">
    <div class="container">
      <h1>LocalDataForge – Hyperlokale Daten. <span style="color:#00C4B3">Maximale Präzision.</span></h1>
      <p>Wir sammeln, strukturieren und veredeln hyperlokale Daten für KI, Navigation, Immobilien und Marktanalysen.</p>
      <p><a class="btn primary" href="#kontakt">Kostenloses Mini-Dataset anfragen</a></p>
    </div>
  </section>
  <section id="leistungen" class="section">
    <div class="container">
      <h2>Leistungen</h2>
      <div class="card"><h3>Lokale Geschäfts-Datasets</h3><p>20–200 Einträge pro Stadtteil. Öffnungszeiten, Besonderheiten, Fotos, Barrierefreiheit.</p></div>
      <div class="card"><h3>Mikro-Preisanalysen</h3><p>Kategorien wie Lebensmittel, Barbershops, Imbisse, Nagelstudios.</p></div>
      <div class="card"><h3>Weg- & Navigationsdaten</h3><p>Dokumentation für Routing, Barrierefreiheit, Topografie.</p></div>
      <div class="card"><h3>Dialekt- & Sprachdatensets</h3><p>Regionale Wörter, Aussprache, Umgangssprache.</p></div>
      <div class="card"><h3>Monatliche Updates (Retainer)</h3><p>Regelmäßige Erweiterungen und Aktualisierungen.</p></div>
    </div>
  </section>
  <section id="preise" class="section alt">
    <div class="container">
      <h2>Preise</h2>
      <ul>
        <li><strong>Shop-Dataset (20–50 Einträge):</strong> 150–450 €</li>
        <li><strong>Mikro-Preisanalysen (pro Kategorie):</strong> 50–250 €</li>
        <li><strong>Weg-/Routing-Dokumentation:</strong> 200–800 €</li>
        <li><strong>Dialekt-Datensets:</strong> 100–500 €</li>
        <li><strong>Monatlicher Retainer:</strong> 300–900 €</li>
      </ul>
    </div>
  </section>
  <section id="kontakt" class="section">
    <div class="container">
      <h2>Kontakt</h2>
      <p>Möchten Sie ein kostenloses Mini-Dataset? Schreiben Sie uns an <a href="mailto:info@localdataforge.com">info@localdataforge.com</a>.</p>
    </div>
  </section>
</main>
<?php get_footer(); ?>
