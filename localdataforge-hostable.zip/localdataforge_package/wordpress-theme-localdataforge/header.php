<!doctype html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<header>
  <div class="container nav">
    <div class="brand">
      <div class="icon"></div>
      <span>LocalDataForge</span>
    </div>
    <nav>
      <a href="#leistungen">Leistungen</a>
      <a href="#preise">Preise</a>
      <a href="#kontakt">Kontakt</a>
    </nav>
  </div>
</header>
