<?php
function localdataforge_enqueue() {
  wp_enqueue_style('inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap', [], null);
  wp_enqueue_style('localdataforge-style', get_stylesheet_uri(), [], '1.0');
}
add_action('wp_enqueue_scripts', 'localdataforge_enqueue');
