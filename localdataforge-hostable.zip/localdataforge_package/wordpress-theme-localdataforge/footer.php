<footer>
  <div class="container">
    <p>© LocalDataForge – Hyperlokale Daten. Maximale Präzision.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body></html>
